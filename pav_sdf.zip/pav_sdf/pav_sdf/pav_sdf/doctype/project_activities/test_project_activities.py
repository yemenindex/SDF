# Copyright (c) 2022, Partner Consulting Solutions and Contributors
# See license.txt

# import frappe
import unittest

class TestProjectActivities(unittest.TestCase):
	pass
