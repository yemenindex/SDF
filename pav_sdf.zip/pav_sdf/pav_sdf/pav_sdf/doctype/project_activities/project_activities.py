# Copyright (c) 2022, Partner Consulting Solutions and contributors
# For license information, please see license.txt

# import frappe
from frappe.utils.nestedset import NestedSet

class ProjectActivities(NestedSet):
	pass
