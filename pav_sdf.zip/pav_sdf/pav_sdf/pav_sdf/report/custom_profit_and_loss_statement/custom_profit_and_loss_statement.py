# Copyright (c) 2015, Frappe Technologies Pvt. Ltd. and Contributors
# License: GNU General Public License v3. See license.txt

from __future__ import unicode_literals
import frappe, erpnext
from frappe import _
from frappe.utils import flt,cstr
from erpnext.accounts.report.financial_statements import (get_period_list)
from erpnext.accounts.doctype.accounting_dimension.accounting_dimension import get_accounting_dimensions, get_dimension_with_children
import re
from past.builtins import cmp
import functools
from six import itervalues

def execute(filters=None):
	period_list = get_period_list(filters.from_fiscal_year, filters.to_fiscal_year,
		filters.periodicity, filters.accumulated_values, filters.company)

	income = get_data(filters.company, "Income", "Credit", period_list, filters = filters,
		accumulated_values=filters.accumulated_values,
		ignore_closing_entries=True, ignore_accumulated_values_for_fy= True)

	expense = get_data(filters.company, "Expense", "Debit", period_list, filters=filters,
		accumulated_values=filters.accumulated_values,
		ignore_closing_entries=True, ignore_accumulated_values_for_fy= True)

	net_profit_loss = get_net_profit_loss(income, expense, period_list, filters.company, filters.presentation_currency)

	# frappe.msgprint("income{0}".format(income))
	# frappe.msgprint("expense{0}".format(expense))
	data = []
	data.extend(income or [])
	data.extend(expense or [])
	if net_profit_loss:
		data.append(net_profit_loss)

	columns = get_columns(filters, filters.periodicity, period_list, filters.accumulated_values, filters.company)

	chart = get_chart_data(filters, columns, income, expense, net_profit_loss)

	return columns, data, None, chart

def get_net_profit_loss(income, expense, period_list, company, currency=None, consolidated=False):
	total = 0
	net_profit_loss = {
		"account_name": "'" + _("Profit for the year") + "'",
		"account": "'" + _("Profit for the year") + "'",
		"warn_if_negative": True,
		"currency": currency or frappe.get_cached_value('Company',  company,  "default_currency")
	}

	has_value = False

	for period in period_list:
		key = period if consolidated else period.key
		total_income = flt(income[-2][key], 3) if income else 0
		total_expense = flt(expense[-2][key], 3) if expense else 0

		net_profit_loss[key] = total_income - total_expense

		if net_profit_loss[key]:
			has_value=True

		total += flt(net_profit_loss[key])
		net_profit_loss["total"] = total

	if has_value:
		return net_profit_loss

def get_chart_data(filters, columns, income, expense, net_profit_loss):
	labels = [d.get("label") for d in columns[2:-6]]

	income_data, expense_data, net_profit = [], [], []

	for p in columns[2:-6]:
		if income:
			income_data.append(income[-2].get(p.get("fieldname")))
		if expense:
			expense_data.append(expense[-2].get(p.get("fieldname")))
		if net_profit_loss:
			net_profit.append(net_profit_loss.get(p.get("fieldname")))

	datasets = []
	if income_data:
		datasets.append({'name': _('Income'), 'values': income_data})
	if expense_data:
		datasets.append({'name': _('Expense'), 'values': expense_data})
	if net_profit:
		datasets.append({'name': _('Net Profit/Loss'), 'values': net_profit})

	chart = {
		"data": {
			'labels': labels,
			'datasets': datasets
		}
	}

	if not filters.accumulated_values:
		chart["type"] = "bar"
	else:
		chart["type"] = "line"

	chart["fieldtype"] = "Currency"

	return chart

def get_data(
		company, root_type, balance_must_be, period_list, filters=None,
		accumulated_values=1, only_current_fiscal_year=True, ignore_closing_entries=False,
		ignore_accumulated_values_for_fy=False , total = True):

	accounts = get_accounts(company, root_type)
	if not accounts:
		return None

	accounts, accounts_by_name, parent_children_map = filter_accounts(accounts)

	company_currency = get_appropriate_currency(company, filters)
	# frappe.msgprint("accounts1={0}".format(accounts))
	gl_entries_by_account = {}
	for root in frappe.db.sql("""select lft, rgt from tabAccount
			where root_type=%s and ifnull(parent_account, '') = ''""", root_type, as_dict=1):

		set_gl_entries_by_account(
			company,
			period_list[0]["year_start_date"] if only_current_fiscal_year else None,
			period_list[-1]["to_date"],
			root.lft, root.rgt, filters,
			gl_entries_by_account, ignore_closing_entries=ignore_closing_entries
		)
	
	calculate_values(
		accounts_by_name, gl_entries_by_account, period_list, accumulated_values, ignore_accumulated_values_for_fy)
	# frappe.msgprint("gl_entries_by_account={0}".format(gl_entries_by_account))
	# frappe.msgprint("accounts_by_name={0}".format(accounts_by_name))
	# frappe.msgprint("accounts222={0}".format(accounts))
	accumulate_values_into_parents(accounts, accounts_by_name, period_list, accumulated_values)
	# frappe.msgprint("accounts_by_name={0}".format(accounts_by_name))
	# frappe.msgprint("accounts333={0}".format(accounts))
	out = prepare_data(accounts, balance_must_be, period_list, company_currency)
	# frappe.msgprint("out1={0}".format(out))
	out = filter_out_zero_value_rows(out, parent_children_map)
	# frappe.msgprint("out2={0}".format(out))
	if out and total:
		add_total_row(out, root_type, balance_must_be, period_list, company_currency)

	return out

def get_accounts(company, root_type):
	return frappe.db.sql("""
		select name, account_number, parent_account, lft, rgt, root_type, report_type, account_name, include_in_gross, account_type, is_group, lft, rgt
		from `tabAccount`
		where company=%s and root_type=%s order by lft""", (company, root_type), as_dict=True)
def filter_accounts(accounts, depth=10):
	parent_children_map = {}
	accounts_by_name = {}
	for d in accounts:
		accounts_by_name[d.name] = d
		parent_children_map.setdefault(d.parent_account or None, []).append(d)

	filtered_accounts = []

	def add_to_list(parent, level):
		if level < depth:
			children = parent_children_map.get(parent) or []
			sort_accounts(children, is_root=True if parent==None else False)

			for child in children:
				child.indent = level
				filtered_accounts.append(child)
				add_to_list(child.name, level + 1)

	add_to_list(None, 0)

	return filtered_accounts, accounts_by_name, parent_children_map

def sort_accounts(accounts, is_root=False, key="name"):
	"""Sort root types as Asset, Liability, Equity, Income, Expense"""

	def compare_accounts(a, b):
		if re.split('\W+', a[key])[0].isdigit():
			# if chart of accounts is numbered, then sort by number
			return cmp(a[key], b[key])
		elif is_root:
			if a.report_type != b.report_type and a.report_type == "Balance Sheet":
				return -1
			if a.root_type != b.root_type and a.root_type == "Asset":
				return -1
			if a.root_type == "Liability" and b.root_type == "Equity":
				return -1
			if a.root_type == "Income" and b.root_type == "Expense":
				return -1
		else:
			# sort by key (number) or name
			return cmp(a[key], b[key])
		return 1

	accounts.sort(key = functools.cmp_to_key(compare_accounts))

def get_appropriate_currency(company, filters=None):
	if filters and filters.get("presentation_currency"):
		return filters["presentation_currency"]
	else:
		return frappe.get_cached_value('Company',  company,  "default_currency")

def set_gl_entries_by_account(
		company, from_date, to_date, root_lft, root_rgt, filters, gl_entries_by_account, ignore_closing_entries=False):
	"""Returns a dict like { "account": [gl entries], ... }"""

	additional_conditions = get_additional_conditions(from_date, ignore_closing_entries, filters)

	accounts = frappe.db.sql_list("""select name from `tabAccount`
		where lft >= %s and rgt <= %s and company = %s""", (root_lft, root_rgt, company))

	if accounts:
		additional_conditions += " and account in ({})"\
			.format(", ".join([frappe.db.escape(d) for d in accounts]))
		additional_conditions2 = " ({})"\
		.format(", ".join([frappe.db.escape(d) for d in accounts]))

		gl_filters = {
			"company": company,
			"from_date": from_date,
			"to_date": to_date,
			"finance_book": cstr(filters.get("finance_book"))
		}

		if filters.get("include_default_book_entries"):
			gl_filters["company_fb"] = frappe.db.get_value("Company",
				company, 'default_finance_book')

		for key, value in filters.items():
			if value:
				gl_filters.update({
					key: value
				})

		select_fields = """ debit, credit """
		if filters.presentation_currency:
			company_currency = erpnext.get_company_currency(filters.company)
			if company_currency != filters.presentation_currency:
				gl_has_currency = frappe.get_all("GL Entry Currency", fields=["currency"], filters={'currency':filters.get('presentation_currency')})
				if gl_has_currency:
					if filters.from_date and filters.to_date:
						select_fields = """ debit_in_{0} as debit, credit_in_{0} as credit, 
						( select IFNULL(sum(g.debit_in_{0}),0) from `tabGL Entry` g where g.account=account and g.posting_date between '{1}' and '{2}') as c_debit, 
						( select IFNULL(sum(g.credit_in_{0}),0) from `tabGL Entry` g where g.account=account and g.posting_date between '{1}' and '{2}') as c_credit""".format(
							frappe.scrub(filters.get('presentation_currency')),filters.from_date,filters.to_date)
						#frappe.msgprint("yy")
					else:
						select_fields = """ debit_in_{0} as debit, credit_in_{0} as credit """.format(frappe.scrub(filters.get('presentation_currency')))
		elif filters.from_date and filters.to_date:	
			select_fields = """ debit, credit, 
			( select IFNULL(sum(g.debit),0) from `tabGL Entry` g where g.account = account and g.posting_date between '{0}' and '{1}') as c_debit, 
			( select IFNULL(sum(g.credit),0) from `tabGL Entry` g where g.account = account and g.posting_date between '{0}' and '{1}') as c_credit""".format(
				filters.from_date,filters.to_date,additional_conditions2)
			#frappe.msgprint("yy")

		gl_entries = frappe.db.sql("""select posting_date, account, {select_fields}, is_opening, fiscal_year, debit_in_account_currency, credit_in_account_currency, account_currency from `tabGL Entry`
			where company=%(company)s
			{additional_conditions}
			and posting_date <= %(to_date)s
			order by account, posting_date""".format(additional_conditions=additional_conditions,select_fields=select_fields), gl_filters, as_dict=True) #nosec
		# frappe.msgprint("gl_entries22={0}".format(gl_entries))
		gl_filters.update({
			"company": company,
			"from_date": filters.from_date,
			"to_date": filters.to_date
		})
		for entry in gl_entries:
			gl_filters.update({			
				"account": entry.account
			})
			c_d_c = frappe.db.sql(""" select IFNULL(sum(debit),0) as debit, IFNULL(sum(credit),0) as credit
				from `tabGL Entry` where 
				company=%(company)s
				{additional_conditions} and account = %(account)s and posting_date between %(from_date)s and %(to_date)s""".
				format(additional_conditions=additional_conditions), gl_filters, as_list=1)
			o_d_c = frappe.db.sql(""" select IFNULL(sum(debit),0) as debit, IFNULL(sum(credit),0) as credit
				from `tabGL Entry` where 
				company=%(company)s
				{additional_conditions} and account = %(account)s and posting_date < %(from_date)s""".
				format(additional_conditions=additional_conditions), gl_filters, as_list=1)
			# frappe.msgprint("c_d_c={0}".format(c_d_c))
			entry.c_debit,entry.c_credit=toggle_debit_credit(flt(c_d_c[0][0]),flt(c_d_c[0][1]))
			entry.o_debit=flt(o_d_c[0][0])
			entry.o_credit=flt(o_d_c[0][1])
			entry.e_debit,entry.e_credit=toggle_debit_credit(entry.o_debit+entry.c_debit,entry.o_credit+entry.c_credit)
			gl_entries_by_account.setdefault(entry.account, []).append(entry)

		return gl_entries_by_account

def get_additional_conditions(from_date, ignore_closing_entries, filters):
	additional_conditions = []

	accounting_dimensions = get_accounting_dimensions(as_list=False)

	if ignore_closing_entries:
		additional_conditions.append("ifnull(voucher_type, '')!='Period Closing Voucher'")

	if from_date:
		additional_conditions.append("posting_date >= %(from_date)s")

	if filters:
		if filters.get("project"):
			if not isinstance(filters.get("project"), list):
				filters.project = frappe.parse_json(filters.get("project"))

			additional_conditions.append("project in %(project)s")

		if filters.get("cost_center"):
			filters.cost_center = get_cost_centers_with_children(filters.cost_center)
			additional_conditions.append("cost_center in %(cost_center)s")

		if filters.get("include_default_book_entries"):
			additional_conditions.append("(finance_book in (%(finance_book)s, %(company_fb)s, '') OR finance_book IS NULL)")
		else:
			additional_conditions.append("(finance_book in (%(finance_book)s, '') OR finance_book IS NULL)")

	if accounting_dimensions:
		for dimension in accounting_dimensions:
			if filters.get(dimension.fieldname):
				if frappe.get_cached_value('DocType', dimension.document_type, 'is_tree'):
					filters[dimension.fieldname] = get_dimension_with_children(dimension.document_type,
						filters.get(dimension.fieldname))
					additional_conditions.append("{0} in %({0})s".format(dimension.fieldname))
				else:
					additional_conditions.append("{0} in (%({0})s)".format(dimension.fieldname))

	return " and {}".format(" and ".join(additional_conditions)) if additional_conditions else ""

def get_cost_centers_with_children(cost_centers):
	if not isinstance(cost_centers, list):
		cost_centers = [d.strip() for d in cost_centers.strip().split(',') if d]

	all_cost_centers = []
	for d in cost_centers:
		if frappe.db.exists("Cost Center", d):
			lft, rgt = frappe.db.get_value("Cost Center", d, ["lft", "rgt"])
			children = frappe.get_all("Cost Center", filters={"lft": [">=", lft], "rgt": ["<=", rgt]})
			all_cost_centers += [c.name for c in children]
		else:
			frappe.throw(_("Cost Center: {0} does not exist".format(d)))

	return list(set(all_cost_centers))

def calculate_values(
		accounts_by_name, gl_entries_by_account, period_list, accumulated_values, ignore_accumulated_values_for_fy):
	for entries in itervalues(gl_entries_by_account):
		for entry in entries:
			d = accounts_by_name.get(entry.account)
			d['c_debit']=entry.c_debit
			d['c_credit']=entry.c_credit
			d['o_debit']=entry.o_debit
			d['o_credit']=entry.o_credit
			d['e_debit']=entry.e_debit
			d['e_credit']=entry.e_credit
			if not d:
				frappe.msgprint(
					_("Could not retrieve information for {0}.".format(entry.account)), title="Error",
					raise_exception=1
				)
			for period in period_list:
				# check if posting date is within the period

				if entry.posting_date <= period.to_date:
					if (accumulated_values or entry.posting_date >= period.from_date) and \
						(not ignore_accumulated_values_for_fy or
							entry.fiscal_year == period.to_date_fiscal_year):
						d[period.key] = d.get(period.key, 0.0) + flt(entry.debit) - flt(entry.credit)

			if entry.posting_date < period_list[0].year_start_date:
				d["opening_balance"] = d.get("opening_balance", 0.0) + flt(entry.debit) - flt(entry.credit)

def accumulate_values_into_parents(accounts, accounts_by_name, period_list, accumulated_values):
	"""accumulate children's values in parent accounts"""
	for d in reversed(accounts):
		if d.parent_account:
			for period in period_list:
				accounts_by_name[d.parent_account][period.key] = \
					accounts_by_name[d.parent_account].get(period.key, 0.0) + d.get(period.key, 0.0)
				accounts_by_name[d.parent_account]['c_debit'] = \
					accounts_by_name[d.parent_account].get('c_debit', 0.0) + d.get('c_debit', 0.0)
				accounts_by_name[d.parent_account]['c_credit'] = \
					accounts_by_name[d.parent_account].get('c_credit', 0.0) + d.get('c_credit', 0.0)				 
				accounts_by_name[d.parent_account]['o_debit'],accounts_by_name[d.parent_account]['o_credit']=toggle_debit_credit(accounts_by_name[d.parent_account].get('o_debit', 0.0) + d.get('o_debit', 0.0),accounts_by_name[d.parent_account].get('o_credit', 0.0) + d.get('o_credit', 0.0))
				accounts_by_name[d.parent_account]['e_debit'],accounts_by_name[d.parent_account]['e_credit']=toggle_debit_credit(accounts_by_name[d.parent_account].get('e_debit', 0.0) + d.get('e_debit', 0.0),accounts_by_name[d.parent_account].get('e_credit', 0.0) + d.get('e_credit', 0.0))
				
				
			
			accounts_by_name[d.parent_account]["opening_balance"] = \
				accounts_by_name[d.parent_account].get("opening_balance", 0.0) + d.get("opening_balance", 0.0)

def prepare_data(accounts, balance_must_be, period_list, company_currency):
	data = []
	year_start_date = period_list[0]["year_start_date"].strftime("%Y-%m-%d")
	year_end_date = period_list[-1]["year_end_date"].strftime("%Y-%m-%d")

	for d in accounts:
		# add to output
		has_value = False
		total = 0
		# frappe.msgprint("d={0}".format(d))
		row = frappe._dict({
			"account": _(d.name),
			"parent_account": _(d.parent_account) if d.parent_account else '',
			"indent": flt(d.indent),
			"year_start_date": year_start_date,
			"year_end_date": year_end_date,
			"currency": company_currency,
			"debit": d.c_debit,
			"credit": d.c_credit,
			"opening_debit": d.o_debit,
			"opening_credit": d.o_credit,
			"closing_debit": d.e_debit,
			"closing_credit": d.e_credit,
			"include_in_gross": d.include_in_gross,
			"account_type": d.account_type,
			"is_group": d.is_group,
			"opening_balance": d.get("opening_balance", 0.0) * (1 if balance_must_be=="Debit" else -1),
			"account_name": ('%s - %s' %(_(d.account_number), _(d.account_name))
				if d.account_number else _(d.account_name))
		})
		for period in period_list:
			if d.get(period.key) and balance_must_be == "Credit":
				# change sign based on Debit or Credit, since calculation is done using (debit - credit)
				d[period.key] *= -1

			row[period.key] = flt(d.get(period.key, 0.0), 3)

			if abs(row[period.key]) >= 0.005:
				# ignore zero values
				has_value = True
				total += flt(row[period.key])

		row["has_value"] = has_value
		row["total"] = total
		data.append(row)

	return data

def filter_out_zero_value_rows(data, parent_children_map, show_zero_values=False):
	data_with_value = []
	for d in data:
		if show_zero_values or d.get("has_value"):
			data_with_value.append(d)
		else:
			# show group with zero balance, if there are balances against child
			children = [child.name for child in parent_children_map.get(d.get("account")) or []]
			if children:
				for row in data:
					if row.get("account") in children and row.get("has_value"):
						data_with_value.append(d)
						break

	return data_with_value

def add_total_row(out, root_type, balance_must_be, period_list, company_currency):
	total_row = {
		"account_name": _("Total {0} ({1})").format(_(root_type), _(balance_must_be)),
		"account": _("Total {0} ({1})").format(_(root_type), _(balance_must_be)),
		"currency": company_currency
	}

	for row in out:
		if not row.get("parent_account"):
			for period in period_list:
				total_row.setdefault(period.key, 0.0)
				total_row[period.key] += row.get(period.key, 0.0)
				row[period.key] = row.get(period.key, 0.0)

			total_row.setdefault("total", 0.0)
			total_row["total"] += flt(row["total"])
			row["total"] = ""

	if "total" in total_row:
		out.append(total_row)

		# blank row after Total
		out.append({})
def toggle_debit_credit(debit, credit):
	if flt(debit) > flt(credit):
		debit = flt(debit) - flt(credit)
		credit = 0.0
	else:
		credit = flt(credit) - flt(debit)
		debit = 0.0
	return debit, credit

def get_columns(filters, periodicity, period_list, accumulated_values=1, company=None):
	columns = [{
		"fieldname": "account",
		"label": _("Account"),
		"fieldtype": "Link",
		"options": "Account",
		"width": 300
	}]
	if company:
		columns.append({
			"fieldname": "currency",
			"label": _("Currency"),
			"fieldtype": "Link",
			"options": "Currency",
			"hidden": 1
		})
	for period in period_list:
		columns.append({
			"fieldname": period.key,
			"label": period.label,
			"fieldtype": "Currency",
			"options": "currency",
			"width": 150
		})
	if periodicity!="Yearly":
		if not accumulated_values:
			columns.append({
				"fieldname": "total",
				"label": _("Total"),
				"fieldtype": "Currency",
				"width": 150
			})
	if filters.from_date and filters.to_date:
		columns.append({
			"fieldname": "opening_debit",
			"label": _("Opening (Dr)"),
			"fieldtype": "Currency",
			"options": "currency",
			"width": 120
		})
		columns.append({
			"fieldname": "opening_credit",
			"label": _("Opening (Cr)"),
			"fieldtype": "Currency",
			"options": "currency",
			"width": 120
		})
		columns.append({
			"fieldname": "debit",
			"label": _("Debit"),
			"fieldtype": "Currency",
			"options": "currency",
			"width": 120
		})
		columns.append({
			"fieldname": "credit",
			"label": _("Credit"),
			"fieldtype": "Currency",
			"options": "currency",
			"width": 120
		})
		columns.append({
			"fieldname": "closing_debit",
			"label": _("Closing (Dr)"),
			"fieldtype": "Currency",
			"options": "currency",
			"width": 120
		})
		columns.append({
			"fieldname": "closing_credit",
			"label": _("Closing (Cr)"),
			"fieldtype": "Currency",
			"options": "currency",
			"width": 120
		})
	return columns