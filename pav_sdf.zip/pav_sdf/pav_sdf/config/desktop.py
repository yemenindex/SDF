# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from frappe import _

def get_data():
	return [
		{
			"module_name": "PAV SDF",
			"color": "grey",
			"icon": "octicon octicon-file-directory",
			"type": "module",
			"label": _("PAV SDF")
		},
		{
			"module_name": "Accounts",
			"category": "Modules",
			"label": _("Accounting"),
			"color": "#3498db",
			"icon": "octicon octicon-repo",
			"type": "module"
		}
	]
