from __future__ import unicode_literals
from frappe import _
import frappe


def get_data():
	return  [		
		{
			"label": _("Leaves"),
			"items": [
				{
					"type": "report",
					"name": "Project Wise Employee Leave Balance",
					"doctype": "Leave Application",
					"is_query_report": True,
					"label":_("Project Wise Employee Leave Balance")
				},
			]
		},
	]
