from __future__ import unicode_literals
from frappe import _
import frappe


def get_data():
	return  [		
		{
			"label": _("Financial Statements"),
			"items": [
				{
					"type": "report",
					"name": "Custom General Ledger 01",
					"doctype": "GL Entry",
					"is_query_report": True,
					"label":_("General Ledger")
				},
				{
					"type": "report",
					"name": "Custom General Ledger MC 01",
					"doctype": "GL Entry",
					"is_query_report": True,
					"label":_("General Ledger MC")
				},
				{
					"type": "report",
					"name":"Custom Trial Balance 01",					
					"doctype": "GL Entry",
					"is_query_report": True,
					"label":_("Trial Balance")
				},
				{
					"type": "report",
					"name":"Custom Profit and Loss Statement 01",					
					"doctype": "GL Entry",
					"is_query_report": True,
					"label":_("Profit and Loss Statement")
				},
				{
					"type": "report",
					"name":"Custom Budget Variance Report 01",					
					"doctype": "GL Entry",
					"is_query_report": True,
					"label":_("Budget Variance Reportr")
				},
				{
					"type": "report",
					"name":"Custom Accounting Dimension Balance 01",					
					"doctype": "GL Entry",
					"is_query_report": True,
					"label":_("Accounting Dimension Balance")
				},
				{
					"type": "report",
					"name":"Trial Balance for Party in Party Currency 01",					
					"doctype": "GL Entry",
					"is_query_report": True,
					"label":_("Trial Balance for Party in Party Currency")
				},
				{
					"type": "report",
					"name":"Currency wise General Ledger",					
					"doctype": "GL Entry",
					"is_query_report": True,
					"label":_("Currency wise General Ledger")
				},
			]
		},	

		{
			"label": _("Expense Claims"),
			"items": [
				{
					"type": "doctype",
					"name": "Expense Entry",
					"description": _("Expense Entry."),
				},
			]
		},	
	]
