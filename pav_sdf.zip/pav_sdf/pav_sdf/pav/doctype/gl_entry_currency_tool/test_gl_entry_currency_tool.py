# -*- coding: utf-8 -*-
# Copyright (c) 2021, Ahmed Mohammed Alkuhlani and Contributors
# See license.txt
from __future__ import unicode_literals

# import frappe
import unittest

class TestGLEntryCurrencyTool(unittest.TestCase):
	pass
