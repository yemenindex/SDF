frappe.listview_settings['Expense Entry'] = {
	onload() {
		frappe.breadcrumbs.add('Accounts');
	},
};