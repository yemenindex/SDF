// Copyright (c) 2022, Partner Consulting Solutions and contributors
// For license information, please see license.txt

frappe.ui.form.on('Project Activity Payroll', {
	// refresh: function(frm) {

	// }
});
