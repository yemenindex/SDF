// Copyright (c) 2020, Ahmed Mohammed Alkuhlani and contributors
// For license information, please see license.txt

frappe.ui.form.on('Employee Account', {
	// refresh: function(frm) {

	// }
});
