// Copyright (c) 2021, Ahmed Mohammed Alkuhlani and contributors
// For license information, please see license.txt

frappe.ui.form.on('GL Entry Currency', {
	// refresh: function(frm) {

	// }
});
