# Copyright (c) 2015, Frappe Technologies Pvt. Ltd. and Contributors
# License: GNU General Public License v3. See license.txt

from __future__ import unicode_literals
import frappe
from frappe.utils import cstr, cint, getdate
from frappe import msgprint, _
from calendar import monthrange

date_format = '%Y-%m-%d'

def execute(filters=None):
	if not filters: filters = {}

	conditions, filters = get_conditions(filters)
	columns = get_columns(filters)
	att_map = get_attendance_list(conditions, filters)
	emp_map = get_employee_details(filters)

	holiday_list = [emp_map[d]["holiday_list"] for d in emp_map if emp_map[d]["holiday_list"]]
	default_holiday_list = frappe.get_cached_value('Company',  filters.get("company"),  "default_holiday_list")
	holiday_list.append(default_holiday_list)
	holiday_list = list(set(holiday_list))


	data = []

	for emp in sorted(att_map):
		emp_det = emp_map.get(emp)
		if not emp_det:
			continue

		row = [emp, emp_det.employee_name, emp_det.branch, emp_det.project, emp_det.department, emp_det.designation,
			emp_det.company]

		total_p = total_a = total_l = total_h = 0.0
		for day in att_map.get(emp):
			status = att_map.get(emp).get(day, "None")

			if status == "Present":
				total_p += 1
			elif status == "Absent":
				total_a += 1
			elif status == "On Leave":
				total_l += 1
			elif status == "Half Day":
				total_h += 1

		row += [total_p, total_h, total_l, total_a]

		
		data.append(row)
	return columns, data

def get_columns(filters):
	columns = [
		_("Employee") + ":Link/Employee:120", _("Employee Name") + "::140", _("Branch")+ ":Link/Branch:120", _("Project")+ ":Link/Project:120",
		_("Department") + ":Link/Department:120", _("Designation") + ":Link/Designation:120",
		 _("Company") + ":Link/Company:120"
	]

	columns += [_("Present") + ":Float:80", _("Half Day") + ":Float:80", _("Leaves") + ":Float:80",  _("Absent") + ":Float:80"]
	return columns

def get_attendance_list(conditions, filters):
	attendance_list = frappe.db.sql("""select employee, attendance_date as day_date,
		status from tabAttendance where docstatus = 1 %s order by employee, attendance_date""" %
		conditions, filters, as_dict=1)

	att_map = {}
	for d in attendance_list:
		date = d.day_date.strftime(date_format)
		att_map.setdefault(d.employee, frappe._dict()).setdefault(date, "")
		att_map[d.employee][date] = d.status

	return att_map

def get_conditions(filters):
	conditions = " and attendance_date >= %(from_date)s and attendance_date <= %(to_date)s "
	if filters.get("company"): conditions += " and company = %(company)s"
	if filters.get("employee"): conditions += " and employee = %(employee)s"

	return conditions, filters

def get_employee_details(filters):
	conditions = ""
	if filters.get("project"): conditions += " and project = %(project)s"
	if filters.get("branch"): conditions += " and branch = %(branch)s"
	
	emp_map = frappe._dict()
	for d in frappe.db.sql("""select name, employee_name, designation, department, branch, company, project,
		holiday_list from tabEmployee where company =  %(company)s {0} """.format(conditions), filters, as_dict=1):
		emp_map.setdefault(d.name, d)

	return emp_map

def get_holiday(holiday_list, filters):
	holiday_map = frappe._dict()
	for d in holiday_list:
		frappe.msgprint(d)
		if d:
			holiday_map.setdefault(d, frappe.db.sql_list('''select day(holiday_date) from `tabHoliday`
				where parent=%s and holiday_date >= %s and holiday_date <= %s''', (d, filters.get("from_date"), filters.get("to_date"))))

	return holiday_map
